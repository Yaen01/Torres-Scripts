#-------------------------Add-EvaluateSTIG--------------------------#

#Moves the evaluateSTIG script into every computer on base

#Created by Yaen Torres Rosales

#--------------------------------------------------------------------#

#Starts workflow
WorkFlow add-evaluateSTIG {

    #Sets the destination of all the evaluate STIG program data
    $sourcePath = ""

    #stores all the computer names in a variable
    $compNames = Get-ADComputer -filter {enabled -eq "true"} -searchbase 'OU=,DC=' | Select-object -ExpandProperty name
    
    #Starts a parallel foreach loop
    foreach -Parallel ($computer in $compNames) {
        #Copies the report if the host is online
        if (test-connection -computername $computer -count 2 -ErrorAction SilentlyContinue) {
            copy-item -path "$sourcePath" -recurse -ErrorAction SilentlyContinue -destination "\\$computer\C$\ProgramData\"
            inlineScript {
                if ($?) {
                    write-host ""
                    write-host "$Using:computer : Successful"
                } else {
                    write-host ""
                    write-host "$Using:computer : Failed to execute"
                }
            }
        } else {
            inlineScript {
                write-host ""
                write-host "$Using:computer : Failed to connect"
            }
        }
    }
    inlineScript {
        write-host ""
        write-host "STIG-Evaluate has been installed in all alive hosts"
        write-host "|------------------------------------------------|"
    }
}

#Calls the initial workflow
add-evaluateSTIG