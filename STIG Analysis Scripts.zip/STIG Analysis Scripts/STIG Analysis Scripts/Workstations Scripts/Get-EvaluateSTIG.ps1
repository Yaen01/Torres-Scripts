#-------------------------Get-EvaluateSTIG--------------------------#

#Copies the latest evaluate-stig report and puts it in the working directory

#Created by Yaen Torres Rosales

#--------------------------------------------------------------------#

#Starts workflow
WorkFlow get-evaluateSTIG {

    #Sets the destination of all the CKL files
    $destPath = ""

    #stores all the computer names in a variable
    $compNames = Get-ADComputer -filter {enabled -eq "true"} -searchbase 'OU=,DC=' | Select-object -ExpandProperty name
    
    #Stores the count for success attempts
    $susCount = 0

    #Starts a parallel foreach loop
    foreach -Parallel ($computer in $compNames) {
        #Copies the report if the host is online
        if (test-connection -computername $computer -count 2 -ErrorAction SilentlyContinue) {
            copy-item -path "\\$computer\C$\ProgramData\Evaluate-STIG\$computer\Checklist\*" -destination $destPath -erroraction SilentlyContinue -Force
            inlineScript {
                if ($?) {
                    write-host ""
                    write-host "$Using:computer : Successful"
                    $susCount = $susCount + 1
                } else {
                    write-host ""
                    write-host "$Using:computer : Failed to copy"
                }
            }
        } else {
            inlineScript {
                write-host ""
                write-host "$Using:computer : Failed to connect"
            }
        }
    }
    inlineScript {
        write-host ""
        write-host "All CKL files from every alive host have been extracted"
        write-host "|-----------------------------------------------------|"
    }
}

#Calls the initial workflow
get-evaluateSTIG