#-------------------------Push-EvaluateSTIG--------------------------#

#Remotely executes the evulaute stig script located in every computer

#Created by Yaen Torres Rosales

#--------------------------------------------------------------------#

#Starts workflow
WorkFlow push-evaluateSTIG {

    #stores all the computer names in a variable
    $compNames = Get-ADComputer -filter {enabled -eq "true"} -searchbase 'OU=,DC=' | Select-object -ExpandProperty name
    
    #Starts a parallel foreach loop
    foreach -Parallel ($computer in $compNames) {
        #Copies the report if the host is online
        if (test-connection -computername $computer -count 2 -ErrorAction SilentlyContinue) {
            inlineScript {
                invoke-command -computername $using:computer -ErrorAction SilentlyContinue -ScriptBlock {C:\ProgramData\Evaluate-STIG\Evaluate-STIG.ps1 -selectstig AdobeAcrobatProDCClassic, Oracle8, Chrome, MSAccess2016, MSOneNote2016, MSPowerPoint2016, MSProject2016, MSSkype2016, Firefox, DotNET4, MSExcel2016, IE11, MSOfficeSystem2016, MSOutlook2016, MSPublisher2016, Win10, MSWord2016, WinFirewall, JavaJRE8, MSEdge, MSOffice365, MSDefender}
                if ($?) {
                    write-host ""
                    write-host "$Using:computer : Successful"
                } else {
                    write-host ""
                    write-host "$Using:computer : Failed to copy"
                }
            }
        } else {
            inlineScript {
                write-host ""
                write-host "$Using:computer : Failed to connect"
            }
        }
    }
    inlineScript {
        write-host ""
        write-host "STIG-Evaluate has been executed on every alive host"
        write-host "|-------------------------------------------------|"
    }
}

#Calls the initial workflow
push-evaluateSTIG