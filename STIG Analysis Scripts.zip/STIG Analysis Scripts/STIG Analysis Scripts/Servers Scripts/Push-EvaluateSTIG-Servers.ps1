#-------------------------Push-EvaluateSTIG-Servers--------------------------#

#Remotely executes the evulaute stig script located in every server

#Created by A1C Torres Rosales/28 CS SCOO/EAFB

#--------------------------------------------------------------------#

#Starts workflow
WorkFlow push-evaluateSTIG {

    #stores all the server names in a variable
    $serverNames = Get-ADComputer -filter "Name -like 'First*'" -searchbase 'OU=,DC=' | Select-object -ExpandProperty name
    
    #Starts a parallel foreach loop
    foreach -Parallel ($server in $serverNames) {
        #Copies the report if the host is online
        if (test-connection -computername $server -count 2 -ErrorAction SilentlyContinue) {
            inlineScript {
                invoke-command -computername $using:server -ErrorAction SilentlyContinue -ScriptBlock {C:\ProgramData\Evaluate-STIG\Evaluate-STIG.ps1 -selectstig WinServer2019, WinServer2016}
                if ($?) {
                    write-host ""
                    write-host "Successful" -f cyan
                } else {
                    write-host ""
                    write-host "Failed to execute" -f Red
                }
            }
        } else {
            inlineScript {
                Write-Host ""
                write-host "Failed to connect" -f Red
            }
        }
    }
}

#Calls the initial workflow
push-evaluateSTIG