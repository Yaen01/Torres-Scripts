#-------------------------Add-EvaluateSTIG-Servers--------------------------#

#Moves the evaluateSTIG script into every server on base

#Created by Yaen Torres Rosales

#--------------------------------------------------------------------#

#Starts workflow
WorkFlow add-evaluateSTIG {

    #Sets the destination of all the evaluate STIG program data
    $sourcePath = "\\fxbm-as-scoo1p\Ellsworth_ADMREPO\SCOO\Torres Scripts\EvaluateSTIG Template\Evaluate-STIG"

    #stores all the server names in a variable
    $serverNames = Get-ADComputer -filter "Name -like 'First*'" -searchbase 'OU=,DC=' | Select-object -ExpandProperty name
    
    #Starts a parallel foreach loop
    foreach -Parallel ($server in $serverNames) {
        #Copies the report if the host is online
        if (test-connection -computername $server -count 2 -ErrorAction SilentlyContinue) {
            copy-item -path "$sourcePath" -recurse -ErrorAction SilentlyContinue -destination "\\$server\C$\ProgramData\"
            inlineScript {
                if ($?) {
                    write-host ""
                    write-host "Successful" -f cyan
                } else {
                    write-host ""
                    write-host "Failed to copy" -f Red
                }
            }
        } else {
            inlineScript {
                write-host ""
                write-host "Failed to connect" -f Red
            }
        }
    }
}

#Calls the initial workflow
add-evaluateSTIG