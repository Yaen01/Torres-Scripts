#-------------------------Get-EvaluateSTIG-Servers--------------------------#

#Copies the latest evaluate-stig report and puts it in the working directory

#Created by Yaen Torres Rosales

#--------------------------------------------------------------------#

#Starts workflow
WorkFlow get-evaluateSTIG {

    #Sets the destionation of all the CKL files
    $destPath = "."

    #stores all the server names in a variable
    $serverNames = Get-ADComputer -filter "Name -like 'First*'" -searchbase 'OU=,DC=' | Select-object -ExpandProperty name
    
    #Starts a parallel foreach loop
    foreach -Parallel ($server in $serverNames) {
        #Copies the report if the host is online
        if (test-connection -computername $server -count 2 -ErrorAction SilentlyContinue) {
            copy-item -path "\\$server\C$\ProgramData\Evaluate-STIG\$server\Checklist\*" -destination $destPath -erroraction SilentlyContinue -Force
            inlineScript {
                if ($?) {
                    write-host ""
                    write-host "Successful" -f cyan
                } else {
                    write-host ""
                    write-host "Failed to copy" -f Red
                }
            }
        } else {
            inlineScript {
                write-host ""
                write-host "Failed to connect" -f Red
            }
        }
    }
}

#Calls the initial workflow
get-evaluateSTIG