#-------------------------Add-McAffeePkg--------------------------#

#Moves a McAffee Package into a list of computers

#Created by Yaen Torres Rosales

#--------------------------------------------------------------------#

#Starts workflow
WorkFlow add-McAffeePkg {

    #Sets the destination of the local frame package template
    $sourcePath = ".\McAffeePkg Template\packagefile.exe"

    #stores all the computer names in a variable
    $compNames = get-content ".\Computers.txt"
    
    #Starts a parallel foreach loop
    foreach -Parallel ($computer in $compNames) {
        #Copies the report if the host is online
        if (test-connection -computername $computer -count 2 -ErrorAction SilentlyContinue) {
            copy-item -path "$sourcePath" -recurse -ErrorAction SilentlyContinue -destination "\\$computer\C$\ProgramData\Packages\"
            inlineScript {
                if ($?) {
                    invoke-command -computername $using:computer -ScriptBlock {Start-Process -Wait -FilePath "C:\ProgramData\Packages\PackageFolder\PackageFile.exe" -ArgumentList "/install=agent /forceinstall /s" -PassThru}
                    write-host ""
                    write-host "$Using:computer : Successful"
                } else {
                    write-host ""
                    write-host "$Using:computer : Failed to execute"
                }
            }
        } else {
            inlineScript {
                write-host ""
                write-host "$Using:computer : Failed to connect"
            }
        }
    }
}

#Calls the initial workflow
add-McAffeePkg