#This script recursively adds a permission group to ROOT documents

#Created by Yaen Torres Rosales

#--------------------------------------------------------------------#

#Creates space
write-host " "

#Grabs server name from user
write-host " "
$server = read-host "Enter server name (Ex: Server)"

#Grabs file share name from user
write-host " "
$share = read-host "Enter file share name (Ex: Server Folder)"

#Concatonates path into $path 
$path = "\\" + $server + "\" + $share

#Stores the permission group
$permGroup = "some permission group"

#Displays child name
write-host ""; write-host ""
write-host "+---------------------------------" $path "--------------------------------+"
write-host ""; write-host ""; write-host ""
write-host "Directory:" $path

#Grabs ACL for each child
$ACL = Get-Acl -Path $path

#Displays ACL for child
write-host ""
(Get-Acl -Path $path).Access | Format-Table IdentityReference,FileSystemRights,AccessControlType,IsInherited,InheritanceFlags -AutoSize

#New rule is created
$newRule = new-object System.Security.Accesscontrol.FileSystemAccessRule ("AREA\$permGroup","Read","Allow")

#New rule is added to ACL variable
$ACL.AddAccessRule($newRule)

#New ACL is set to the actual path
set-acl -path $path -ErrorAction silentlycontinue -aclobject $ACL

#Displays new ACL for child
(Get-Acl -Path $path).Access | Format-Table IdentityReference,FileSystemRights,AccessControlType,IsInherited,InheritanceFlags -AutoSize

#Outputs that script has been successfully ran
write-host "$permGroup has been added to the directory"; write-host ""