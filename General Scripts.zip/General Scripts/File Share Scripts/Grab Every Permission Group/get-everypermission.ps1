
$servers = "server5", "server5", "server5", "server5", "server5"

$jobs = foreach ($server in $servers) {
    
    Start-Job -ScriptBlock {
        
        param($server)
        
        $permissionGroups = @()
                
        $folders = get-childitem "\\$Server\" -file -recurse -erroraction silentlycontinue
        
        # Create a collection of all permission groups from all folders
        $folders | ForEach-Object {
            $permissionGroups += (Get-Acl $_.Fullname).access | select-object -expandproperty IdentityReference
        }
        return $permissionGroups
    } -ArgumentList $server
    $jobs += $job
}

# Wait for all jobs to complete
Wait-Job $jobs

$results = foreach ($job in $jobs) {
    
    receive-job $job.id
}

# Remove duplicate permission groups
$uniquePermissionGroups = $results | select-object -Unique

# Output the unique permission groups to a csv file
$uniquepermissionGroups | export-csv -Path "C:\permission_groups.csv" -noTypeInformation