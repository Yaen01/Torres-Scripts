﻿#This script recursively adds a permission group

#Created by Yaen Torres Rosales

#--------------------------------------------------------------------#

#Creates space
write-host " "

#Grabs server name from user
write-host " "
$server = read-host "Enter server name (Ex: server name)"

#Grabs file share name from user
write-host " "
$share = read-host "Enter file share name (Ex: File share)"

#Concatonates path into $path 
$path = "\\" + $server + "\" + $share

#Stores the permission group
$permGroup = "example.perm"

#Starts recursive Get-ChildItem
$time = measure-command {$subPaths = Get-childitem -recurse -force -ErrorAction silentlycontinue -path $path}

#Gets the total count of directories for progress bar
$total = $subPaths.count

#Dipslays total minutes for gci command
write-host ""
write-host "Object creation took" $time.TotalMinutes "minutes and has a total of $total directories"
write-host ""

#Loops through the whole
foreach ($child in $subPaths) {

    #Math for Progress Bar
    $count += 1

    $status = "Adding to " + $child.FullName

    $percent = (($count / $total) * 100)

    $percentRounded = [math]::Round($percent,2).ToString() + "%"

    #Displays Progress Bar
    Write-Progress -Activity "Adding group $permGroup, $percentRounded completed" -status $status -PercentComplete $percent

    #Displays child name
    write-host ""; write-host ""
    write-host "+---------------------------------" $child.name "--------------------------------+"
    write-host ""; write-host ""; write-host ""
    write-host "Directory:" $child.FullName

    #Grabs ACL for each child
    $ACL = Get-Acl -Path $child.FullName

    #Displays ACL for child
    write-host ""
    (Get-Acl -Path $child.FullName).Access | Format-Table IdentityReference,FileSystemRights,AccessControlType,IsInherited,InheritanceFlags -AutoSize

    #New rule is created
    $newRule = new-object System.Security.Accesscontrol.FileSystemAccessRule ("AREA\$permGroup","Read","Allow")

    #New rule is added to ACL variable
    $ACL.AddAccessRule($newRule)

    #New ACL is set to the actual path
    set-acl -path $child.FullName -ErrorAction silentlycontinue -aclobject $ACL

    #Displays new ACL for child
    (Get-Acl -Path $child.FullName).Access | Format-Table IdentityReference,FileSystemRights,AccessControlType,IsInherited,InheritanceFlags -AutoSize

}

#Outputs that script has been successfully ran
write-progress -activity "$permGroup added to all sub directories" -Completed
write-host "$permGroup has been added to all sub directories"; write-host ""