﻿#-------------------------Recursive Get Size--------------------------#

#This scripts recursively measures how much data is being used in a path

#Created by Yaen Torres Rosales

#--------------------------------------------------------------------#

$global:totalDir = 0

function Get-PathSize ($path) {
    #Starts recursive Get-ChildItem
    $subPaths = Get-childitem -Directory -force -ErrorAction silentlycontinue -path $path

    write-host ""

    #Loops through the whole
    foreach ($child in $subPaths) {

        $RecurseGCI = Get-childitem -force -ErrorAction silentlycontinue -recurse -path $child.FullName

        #Recursively grabs the size of all directories within the sub and sums the length
        $size = ($recurseGCI | measure-object -property length -Sum -ErrorAction silentlycontinue).sum
        
        #Grabs the total amount of directories
        $global:totalDir = $global:totalDir + $recurseGCI.count

        #Directories with morethan 1 TB are outputted
        if (($size / 1TB) -gt 1) {
            $sizeTB = $size / 1TB
            $sizeTB = [math]::Round($sizeTB, 2)
            write-host $child.name ": " -f green -nonewline; write-host $sizeTB "TB" -f red

        #Directories with morethan 1 GB are outputted
        } elseif (($size / 1GB) -gt 1) {
            $sizeGB = $size / 1GB
            $sizeGB = [math]::Round($sizeGB, 2)
            write-host $child.name ": " -f green -nonewline; write-host $sizeGB "GB" -f magenta
        
        #Directories with morethan 1 MB are outputted
        } elseif (($size / 1MB) -gt 1) {
            $sizeMB = $size / 1MB
            $sizeMB = [math]::Round($sizeMB, 2)
            write-host $child.name ": " -f green -nonewline; write-host $sizeMB "MB" -f cyan
        
        #Directories with morethan 1 KB are outputted
        } else {
            $sizeKB = $size / 1KB
            $sizeKB = [math]::Round($sizeKB, 2)
            write-host $child.name ": " -f green -nonewline; write-host $sizeKB "KB" -f gray
        }

        #Stores the total size of all directories
        $size = $size / 1KB
        $size = [math]::Round($size, 2)
        $global:totalSize = $global:totalsize + $size
    }

    #Script has finished
    write-host ""; write-host "+-------------------------------------------------------------------------+" -f cyan; write-host ""

    if (($global:totalSize / 1GB) -gt 1) {
        $global:totalSize = $global:totalSize / 1GB
        $global:totalSize = [math]::Round($global:totalSize, 2)
        write-host "The total directory size is " -nonewline; write-host $global:totalSize "TB" -f magenta

    } elseif (($global:totalSize / 1MB) -gt 1) {
        $global:totalSize = $global:totalSize / 1MB
        $global:totalSize = [math]::Round($global:totalSize, 2)
        write-host "The total directory size is " -nonewline; write-host $global:totalSize "GB" -f cyan

    } else {
        $global:totalSize = $global:totalSize / 1KB
        $global:totalSize = [math]::Round($global:totalSize, 2)
        write-host "The total directory size is " -nonewline; write-host $global:totalSize "MB" -f gray
    }
}

#Prompts user for path
$path = read-host "Enter full path (Ex: \\Server\Serverfolder)"

#Get-PathSize function is called and time is measured
$global:time = measure-command {Get-PathSize $path}

#Rounds the time variable and turns it to minutes
$STime = [math]::Round($global:time.TotalMinutes, 2)

#Finished message with the output variables
write-host ""; write-host "Script time was " -nonewline; write-host $STime -nonewline -f cyan
write-host " minutes and went through a total of " -nonewline; write-host $global:totalDir -nonewline -f cyan
write-host " directories"; write-host ""