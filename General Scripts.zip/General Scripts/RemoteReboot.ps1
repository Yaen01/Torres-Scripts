#-------------------------Remote Reboot--------------------------#

#This script remotely reboots the selected computer

#Created by Yaen Torres Rosales

#--------------------------------------------------------------------#

function Restart-RemoteComputer {
    
    write-host ""; $computer = read-host "Enter computer name"

    invoke-command -computername $computer -erroraction silentlycontinue {
        restart-computer -Force
    }

    if ($?) {
        write-host ""
        write-host "Results for " -nonewline; write-host $computer -f Yellow -nonewline
        write-host " : Restarted" -f cyan
        write-host ""
    } else {
        write-host ""
        write-host "Results for " -NoNewline; write-host $computer -f Yellow -nonewline
        write-host " : Failed" -f Red
        Restart-RemoteComputer
    }
}

Restart-RemoteComputer