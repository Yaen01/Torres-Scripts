#-------------------------Push-ParallelPing--------------------------#

#Pings multiple computers rapidly with a list

#Created by Yaen Torres Rosales

#--------------------------------------------------------------------#

#Starts workflow
WorkFlow Push-ParallelPing {

    #stores the computer list in variable
    $compNames = get-content ".\Computers.txt"
    
    #Starts a parallel foreach loop
    foreach -Parallel ($computer in $compNames) {
        if (test-connection -computername $computer -count 2 -ErrorAction SilentlyContinue) {
            inlineScript {
                write-host "$Using:computer : Successful"
            }
        } else {
            inlineScript {
                write-host "$Using:computer : Unsuccessful"
            }
        }
    }
}

#Calls the initial workflow
Push-ParallelPing