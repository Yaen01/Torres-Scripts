#-------------------------get-usercomputer--------------------------#

#Find a specific user session by searching through all computers

#Created by Yaen Torres Rosales

#--------------------------------------------------------------------#

#Starts workflow
WorkFlow get-loggedinuser {

    #Change to the DODID you want to search
    $DODID = "1234"

    #stores all the computer names in a variable
    $compNames = Get-ADComputer -filter {enabled -eq "true"} -searchbase 'OU=,DC=' | Select-object -ExpandProperty name
    
    #Starts a parallel foreach loop
    foreach -Parallel ($computer in $compNames) {
        #Checks for users if the host is online
        if (test-connection -computername $computer -count 2 -ErrorAction SilentlyContinue) {
            $User = get-wmiobject -computername $computer -class win32_computersystem | select-object Username
            $User = $User.username.split('/')[1]
            if ($User -eq $DODID) {
                inlineScript {
                    write-host ""
                    write-host $Using:computer
                    write-host $Using:DODID
                }
            }
        }
    }
}

#Calls the initial workflow
get-loggedinuser