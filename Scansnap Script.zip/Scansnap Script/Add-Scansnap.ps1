#-------------------------Add-Scansnap--------------------------#

#Moves the scansnap software into a list of computers and install the software

#Created by Yaen Torres Rosales

#--------------------------------------------------------------------#

#Starts workflow
WorkFlow add-Scansnap {

    #Sets the destination of all the evaluate STIG program data
    $sourcePath = ""

    #stores all the computer names in a variable
    $compNames = get-content ""
    
    #Starts a parallel foreach loop
    foreach -Parallel ($computer in $compNames) {
        #Copies the report if the host is online
        if (test-connection -computername $computer -count 2 -ErrorAction SilentlyContinue) {
            copy-item -path "$sourcePath" -recurse -ErrorAction SilentlyContinue -destination "\\$computer\C$\ProgramData\"
            inlineScript {
                if ($?) {
                    invoke-command -computername $using:computer -ScriptBlock {Start-Process -Wait -FilePath "C:\ProgramData\Scansnap Template\Software.exe" -ArgumentList "/S" -PassThru}
                    write-host ""
                    write-host "$Using:computer : Successful"
                } else {
                    write-host ""
                    write-host "$Using:computer : Failed to execute"
                }
            }
        } else {
            inlineScript {
                write-host ""
                write-host "$Using:computer : Failed to connect"
            }
        }
    }
}

#Calls the initial workflow
add-Scansnap